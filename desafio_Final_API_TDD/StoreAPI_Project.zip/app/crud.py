
from app.database import db
from app.schemas import Product
from bson import ObjectId

collection = db["products"]

async def create_product(product: Product):
    doc = product.dict()
    result = await collection.insert_one(doc)
    return str(result.inserted_id)

async def get_products():
    products = []
    cursor = collection.find({})
    async for doc in cursor:
        doc["id"] = str(doc["_id"])
        doc.pop("_id")
        products.append(doc)
    return products

async def get_product(id: str):
    doc = await collection.find_one({"_id": ObjectId(id)})
    if doc:
        doc["id"] = str(doc["_id"])
        doc.pop("_id")
    return doc

async def delete_product(id: str):
    result = await collection.delete_one({"_id": ObjectId(id)})
    return result.deleted_count
