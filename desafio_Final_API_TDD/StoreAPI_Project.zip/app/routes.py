
from fastapi import APIRouter, HTTPException
from app.schemas import Product
from app.crud import create_product, get_products, get_product, delete_product

router = APIRouter()

@router.post("/products", status_code=201)
async def create(product: Product):
    try:
        id = await create_product(product)
        return {"id": id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/products")
async def list_products():
    return await get_products()

@router.get("/products/{id}")
async def get_one(id: str):
    product = await get_product(id)
    if not product:
        raise HTTPException(status_code=404, detail="Not Found")
    return product

@router.delete("/products/{id}", status_code=204)
async def delete(id: str):
    deleted = await delete_product(id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Not Found")
